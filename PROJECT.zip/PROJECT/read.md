<!-- Thankyou for visiting app
for running the app follow the steps below
1. download dependencies using npm install
then run app by using npm start  -->