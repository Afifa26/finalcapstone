export const setSearchItemName = (name) => {
   return {
      type: "SET_SEARCH_ITEM_NAME",
      payload: name
   }
}